#!/bin/sh

./ssh.sh
./fusion_inventory.sh
vnc/vnc.sh
./shorewall.sh
./update_manager.sh
